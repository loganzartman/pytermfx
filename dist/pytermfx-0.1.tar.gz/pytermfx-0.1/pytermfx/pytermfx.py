ESC = "\x1b"
CSI = ESC + "["
from setuptools import setup

setup(name="pytermfx",
      version="0.1",
      description="",
      url="https://github.com/loganzartman/pytermfx",
      author="Logan",
      author_email="",
      license="MIT",
      packages=["pytermfx"],
      zip_safe=False)